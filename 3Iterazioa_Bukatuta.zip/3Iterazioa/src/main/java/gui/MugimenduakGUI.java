package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JComboBox;

import domain.Erregistratua;
import domain.Event;
import domain.Mugimendua;
import domain.Question;
import exceptions.KuotaAlreadyExist;
import businessLogic.BLFacade;
import businessLogic.BLFacadeImplementation;
import configuration.UtilDate;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTextPane;

public class MugimenduakGUI {

	BLFacade facade=MainGUI.getBusinessLogic();
	
	private JFrame frame;
	DefaultListModel<Mugimendua> MugimenduakModel = new DefaultListModel();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MugimenduakGUI window = new MugimenduakGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MugimenduakGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 650, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
//		for(int i =0; i < mug.size();i++) {
//			MugimenduakModel.addElement(mug.get(i).toString());
//		}
		
		
		
//		JList = new JList(MugimenduakModel);
//		MugimenduakModel.setBounds(190, 11, 185, 239);
//		frame.getContentPane().add(MugimenduakModel);
		
		JLabel lblZureMugimenduak = new JLabel("Zure mugimenduak:");
		lblZureMugimenduak.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblZureMugimenduak.setBounds(29, 51, 130, 24);
		frame.getContentPane().add(lblZureMugimenduak);
		
		JTextPane MugList = new JTextPane();
		MugList.setBounds(206, 51, 388, 176);
		frame.getContentPane().add(MugList);
		
		
		
		Vector<Mugimendua> mug = facade.getAllMugs();
		
		String textua ="";
		for(int i=mug.size()-1; i>=0; i--) {			
			textua =textua + mug.get(i) + "\n";
			mug.get(i).setMugId(i);
		}
		MugList.setText(textua);
		
		JButton jButtonClose = new JButton("Close");
		jButtonClose.setBounds(527, 239, 117, 29);
		frame.getContentPane().add(jButtonClose);
		jButtonClose.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				jButtonClose_actionPerformed(e);
			}
		});
	}
	
	
	public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}
	private void jButtonClose_actionPerformed(ActionEvent e) {
		this.setVisible(false);
	}
}