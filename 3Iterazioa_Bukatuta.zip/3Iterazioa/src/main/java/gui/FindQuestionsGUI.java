package gui;

import businessLogic.BLFacade;
import configuration.UtilDate;

import com.toedter.calendar.JCalendar;

import domain.Apustua;
import domain.Erregistratua;
import domain.Kuota;
import domain.Mugimendua;
import domain.Question;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.text.DateFormat;
import java.util.*;

import javax.swing.table.DefaultTableModel;


public class FindQuestionsGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	
	
	private JTextField dir;
	
	private Vector<Apustua> apustuLista=new Vector<Apustua>();
	
	
	
	private domain.Event unekoGertaera=null;
	private domain.Question unekoaGaldera=null;

	private final JLabel jLabelEventDate = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("EventDate"));
	private final JLabel jLabelQueries = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("Queries")); 
	private final JLabel jLabelEvents = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("Events")); 

	private JButton jButtonClose = new JButton(ResourceBundle.getBundle("Etiquetas").getString("Close"));
	private JButton jButtonApostuaKonfirmatu = new JButton(ResourceBundle.getBundle("Etiquetas").getString("ConfirmBets"));
	private JButton jButtonApostuaGehitu = new JButton(ResourceBundle.getBundle("Etiquetas").getString("AddBet"));
	
	private JComboBox<String> aukerak;
	private DefaultComboBoxModel<String> aukeraIzenak = new DefaultComboBoxModel<String>();
	

	// Code for JCalendar
	private JCalendar jCalendar1 = new JCalendar();
	private Calendar calendarMio = null;
	private JScrollPane scrollPaneEvents = new JScrollPane();
	private JScrollPane scrollPaneQueries = new JScrollPane();

	private JTable tableEvents= new JTable();
	private JTable tableQueries = new JTable();

	private DefaultTableModel tableModelEvents;
	private DefaultTableModel tableModelQueries;

	
	private String[] columnNamesEvents = new String[] {
			ResourceBundle.getBundle("Etiquetas").getString("EventN"), 
			ResourceBundle.getBundle("Etiquetas").getString("Event"), 

	};
	private String[] columnNamesQueries = new String[] {
			ResourceBundle.getBundle("Etiquetas").getString("QueryN"), 
			ResourceBundle.getBundle("Etiquetas").getString("Query")

	};

	public FindQuestionsGUI()
	{
		try
		{
			jbInit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
	private void jbInit() throws Exception
	{

		this.getContentPane().setLayout(null);
		this.setSize(new Dimension(700, 900));
		this.setTitle(ResourceBundle.getBundle("Etiquetas").getString("QueryQueries"));

		jLabelEventDate.setBounds(new Rectangle(40, 15, 140, 25));
		jLabelQueries.setBounds(138, 212, 406, 14);
		jLabelEvents.setBounds(295, 19, 259, 16);

		this.getContentPane().add(jLabelEventDate, null);
		this.getContentPane().add(jLabelQueries);
		this.getContentPane().add(jLabelEvents);
		
		
		
		
		
		dir = new JTextField();
		dir.setBounds(415, 416, 128, 20);
		this.getContentPane().add(dir);
		dir.setColumns(10);
		
		JLabel lblErabiltzaileIzena = new JLabel("Sartu dirua:");
		lblErabiltzaileIzena.setBounds(328, 416, 128, 20);
		this.getContentPane().add(lblErabiltzaileIzena);
		
		final JTextPane MugList = new JTextPane();
		MugList.setBounds(125, 530, 388, 176);
		this.getContentPane().add(MugList);
		
		
		
		
		jButtonApostuaGehitu.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(unekoGertaera==null) {
					System.out.println("Ez duzu aukeratu gertaera.");
					return;
				}
				
				
				
				if(unekoaGaldera==null) {
					System.out.println("Galdera ez duzu aukeratu.");
					return;
				
				}
				
				Double	sartutakoDirua= null;
				
				try {
				sartutakoDirua =  Double.parseDouble(dir.getText());
				}catch (Exception a) {
				
				}
				if(sartutakoDirua==null) {
					System.out.println("Ez duzu dirurik sartu.");
					return;
				}else if(sartutakoDirua<=0){
					System.out.println("Diruak ezin du negatibo izan.");
					return;
				}
				
				String aukeratutakoa=null;
				try {
				aukeratutakoa=(String) aukerak.getSelectedItem();
				
				Erregistratua erregistratua=(Erregistratua) MainGUI.getBusinessLogic().erabiltzaileaBadago(MainGUI.izena, MainGUI.pasahitza);
				double bider =2;
				
				if (unekoaGaldera.getKuotak()!=null) {
					
		
				for(int i=0;i<unekoaGaldera.getKuotak().size();i++) {
					if(unekoaGaldera.getKuotak().get(i).getInfo().trim().equals(aukeratutakoa.trim())) {
						bider=unekoaGaldera.getKuotak().get(i).getBiderkatzailea();
						
					}
				}
				unekoaGaldera.getKuotak();
				}
				Apustua a = new Apustua(sartutakoDirua, unekoaGaldera, unekoGertaera, erregistratua, sartutakoDirua*bider, aukeratutakoa);
				apustuLista.add(a);
				String	textua=MugList.getText();
				MugList.setText(textua + a.toString() + "\n");
				}catch (Exception e1) {
					// TODO: handle exception
				}
			}
		});

		jButtonClose.setBounds(new Rectangle(564, 442, 130, 30));
		
		

		jButtonClose.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				jButton2_actionPerformed(e);
			}
		});
		

		this.getContentPane().add(jButtonClose, null);
		
		jButtonApostuaGehitu.setBounds(new Rectangle(390, 374, 130, 30));
		
		jButtonApostuaKonfirmatu.setBounds(new Rectangle(390, 775, 130, 30));

		jButtonApostuaKonfirmatu.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{ 
				
				Erregistratua erregistratua=(Erregistratua) MainGUI.getBusinessLogic().erabiltzaileaBadago(MainGUI.izena, MainGUI.pasahitza);
			
				for(Apustua a:apustuLista) {
				double sartutakoDirua=a.getDirua();
				
				MainGUI.getBusinessLogic().saldoaGehitu(MainGUI.izena,-sartutakoDirua);
		
				Mugimendua m = new Mugimendua(sartutakoDirua, "apostatu", new Date(),erregistratua);
				MainGUI.getBusinessLogic().gordeMugimendua(m);
				
				MainGUI.getBusinessLogic().gordeApustua(a);
				
				}
				
				
				
			}
		});
		
		this.getContentPane().add(jButtonApostuaGehitu, null);
		
		this.getContentPane().add(jButtonApostuaKonfirmatu, null);
		
		
		aukerak = new JComboBox<String>();
		aukerak.setBounds(148, 376, 116, 27);
		this.getContentPane().add(aukerak);
		aukerak.setModel(aukeraIzenak);
		
		
		aukeraIzenak.addElement("1");
		aukeraIzenak.addElement("X");
		aukeraIzenak.addElement("2");
		
	
		aukerak.setSelectedIndex(0);

		jCalendar1.setBounds(new Rectangle(40, 50, 225, 150));


		// Code for JCalendar
		this.jCalendar1.addPropertyChangeListener(new PropertyChangeListener()
		{
			public void propertyChange(PropertyChangeEvent propertychangeevent)
			{

				if (propertychangeevent.getPropertyName().equals("locale"))
				{
					jCalendar1.setLocale((Locale) propertychangeevent.getNewValue());
				}
				else if (propertychangeevent.getPropertyName().equals("calendar"))
				{
					calendarMio = (Calendar) propertychangeevent.getNewValue();
					DateFormat dateformat1 = DateFormat.getDateInstance(1, jCalendar1.getLocale());
					jCalendar1.setCalendar(calendarMio);
					Date firstDay=UtilDate.trim(new Date(jCalendar1.getCalendar().getTime().getTime()));



					try {
						tableModelEvents.setDataVector(null, columnNamesEvents);
						tableModelEvents.setColumnCount(3); // another column added to allocate ev objects

						BLFacade facade=MainGUI.getBusinessLogic();

						Vector<domain.Event> events=facade.getEvents(firstDay);

						if (events.isEmpty() ) jLabelEvents.setText(ResourceBundle.getBundle("Etiquetas").getString("NoEvents")+ ": "+dateformat1.format(calendarMio.getTime()));
						else jLabelEvents.setText(ResourceBundle.getBundle("Etiquetas").getString("Events")+ ": "+dateformat1.format(calendarMio.getTime()));
						for (domain.Event ev:events){
							Vector<Object> row = new Vector<Object>();

							System.out.println("Events "+ev);

							row.add(ev.getEventNumber());
							row.add(ev.getDescription());
							row.add(ev); // ev object added in order to obtain it with tableModelEvents.getValueAt(i,2)
							tableModelEvents.addRow(row);		
						}
						tableEvents.getColumnModel().getColumn(0).setPreferredWidth(25);
						tableEvents.getColumnModel().getColumn(1).setPreferredWidth(268);
						tableEvents.getColumnModel().removeColumn(tableEvents.getColumnModel().getColumn(2)); // not shown in JTable
					} catch (Exception e1) {

						jLabelQueries.setText(e1.getMessage());
					}

				}
				CreateQuestionGUI.paintDaysWithEvents(jCalendar1);
			} 
		});

		this.getContentPane().add(jCalendar1, null);
		
		scrollPaneEvents.setBounds(new Rectangle(292, 50, 346, 150));
		scrollPaneQueries.setBounds(new Rectangle(138, 238, 406, 116));

		tableEvents.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i=tableEvents.getSelectedRow();
				domain.Event ev=(domain.Event)tableModelEvents.getValueAt(i,2); // obtain ev object
				unekoGertaera =ev;
				Vector<Question> queries=ev.getQuestions();

				tableModelQueries.setDataVector(null, columnNamesQueries);

				if (queries.isEmpty())
					jLabelQueries.setText(ResourceBundle.getBundle("Etiquetas").getString("NoQueries")+": "+ev.getDescription());
				else 
					jLabelQueries.setText(ResourceBundle.getBundle("Etiquetas").getString("SelectedEvent")+" "+ev.getDescription());

				for (domain.Question q:queries){
					Vector<Object> row = new Vector<Object>();

					row.add(q.getQuestionNumber());
					row.add(q.getQuestion());
					row.add(q);
					tableModelQueries.addRow(row);	
				}
				tableQueries.getColumnModel().getColumn(0).setPreferredWidth(25);
				tableQueries.getColumnModel().getColumn(1).setPreferredWidth(268);
				//tableQueries.getColumnModel().removeColumn(tableQueries.getColumnModel().getColumn(2)); // not shown in JTable

			}
		});
		
		tableQueries.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				int i=tableQueries.getSelectedRow();
				System.out.println("galdera aldatuta");
				//domain.Question que=(domain.Question)tableModelQueries.getValueAt(i,2); // obtain ev object
				unekoaGaldera=unekoGertaera.getQuestions().get(i);
				
			}
		});

		scrollPaneEvents.setViewportView(tableEvents);
		tableModelEvents = new DefaultTableModel(null, columnNamesEvents);

		tableEvents.setModel(tableModelEvents);
		tableEvents.getColumnModel().getColumn(0).setPreferredWidth(25);
		tableEvents.getColumnModel().getColumn(1).setPreferredWidth(268);


		scrollPaneQueries.setViewportView(tableQueries);
		tableModelQueries = new DefaultTableModel(null, columnNamesQueries);

		tableQueries.setModel(tableModelQueries);
		tableQueries.getColumnModel().getColumn(0).setPreferredWidth(25);
		tableQueries.getColumnModel().getColumn(1).setPreferredWidth(268);

		this.getContentPane().add(scrollPaneEvents, null);
		this.getContentPane().add(scrollPaneQueries, null);

	}

	private void jButton2_actionPerformed(ActionEvent e) {
		this.setVisible(false);
	}

}
