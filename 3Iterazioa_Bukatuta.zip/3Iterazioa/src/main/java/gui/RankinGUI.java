package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import businessLogic.BLFacade;
import domain.Erabiltzailea;
import domain.Erregistratua;
import domain.Mugimendua;


import javax.swing.JFormattedTextField;
import javax.swing.JList;
import javax.swing.JComboBox;

public class RankinGUI {

	BLFacade facade=MainGUI.getBusinessLogic();
	
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RankinGUI window = new RankinGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RankinGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "null", "unchecked" })
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 550, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
//		JTextPane MugList = new JTextPane();
//		MugList.setBounds(50, 51, 166, 78);
//		frame.getContentPane().add(MugList);
		
		
		
		JButton jButtonClose = new JButton("Close");
		jButtonClose.setBounds(300, 277, 117, 29);
		frame.getContentPane().add(jButtonClose);
		jButtonClose.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				jButtonClose_actionPerformed(e);
			}
		});
		
		final JButton erreplika = new JButton("Erreplikatu");
		erreplika.setBounds(341, 122, 117, 29);
		frame.getContentPane().add(erreplika);
		
		
		//try {
	
		List<Erabiltzailea> erabiltzaileak = facade.lortuErabiltzaileGuztiak();
		final Vector<Erregistratua> erregistratuak = new Vector<Erregistratua>();
	
		for(Erabiltzailea erab: erabiltzaileak) {
			Erregistratua erreg =(Erregistratua) erab;
			erregistratuak.add(erreg);
			
			
		}
		//Collections.sort(erregistratuak);
		
//		String textua= "";
//		int kop=0;
//		for(Erregistratua erreg:erregistratuak) {
//			kop++;
//			if(kop<=10) {
//			System.out.println(erreg.getIz() + erreg.kalkulatuIrabazia());
//			textua=textua + (erreg.getIz() + " - "+ erreg.kalkulatuIrabazia()+ "\n");
//			}
//		}
//		
//		MugList.setText(textua);
		
		DefaultListModel<String> erregList = new DefaultListModel<String>();
		
		final JList list = new JList();
		list.setBounds(38, 33, 173, 181);
		frame.getContentPane().add(list);
		int kop = 0;
		for(Erregistratua erreg : erregistratuak) {
			kop++;
			
			if(kop<=10) {
				
				erregList.addElement(erreg.getIz()+" => " +erreg.kalkulatuIrabazia());
			}
		}
		list.setModel(erregList);
		
		final JComboBox ehunekoa = new JComboBox();
		ehunekoa.setBounds(285, 81, 173, 29);
		frame.getContentPane().add(ehunekoa);
		ehunekoa.addItem("%100");
		ehunekoa.addItem("%50");
		ehunekoa.addItem("%20");
		
		final JLabel lblNewLabel = new JLabel("Diru kantitatea:");
		lblNewLabel.setBounds(285, 49, 173, 23);
		frame.getContentPane().add(lblNewLabel);

		
		final Vector<Erregistratua> a = new Vector<Erregistratua>();
		final Vector<Double> b = new Vector<Double>();

		
		erreplika.addActionListener(new ActionListener() {
			int zein = -1;
			public void actionPerformed(ActionEvent e) {
				
				zein = list.getSelectedIndex();
				
				Erregistratua auk = erregistratuak.get(zein);
				
				if(auk.getErreplika()==null) {
				auk.setErreplika(a);
				}
				if(auk.getBiderkatzailea()==null) {
					auk.setBiderkatzailea(b);
				}
				
//				auk.setErreplika(a);
//				auk.setBiderkatzailea(b);
				
				int x = ehunekoa.getSelectedIndex();
				Erregistratua unekoa = (Erregistratua) MainGUI.getBusinessLogic().erabiltzaileaBadago(MainGUI.izena, MainGUI.pasahitza);
//				System.out.println("---------------");
//				System.out.println(unekoa.getIz());
//				System.out.println("---------------");
//				System.out.println(auk.getIz());
//				System.out.println("---------------");
//				System.out.println(Integer.toString(x));
//				System.out.println("---------------");
				if(unekoa.getIz().equals(auk.getIz())==true) {
					System.out.println("Ezin dezu zure burua erreplikatu");
				}else {
					if (x==0 ) {
						auk.sartuErreplika(unekoa);
						auk.sartuBiderkatzailea(1.0);
						System.out.println("---------------");
						System.out.println("%100"+"-----"+auk.getIz()+"-----"+unekoa.getIz());
						System.out.println("---------------");
					}else if (x==1 ) {
						auk.sartuErreplika(unekoa);
						auk.sartuBiderkatzailea(0.5);
						System.out.println("---------------");
						System.out.println("%50"+"-----"+auk.getIz()+"-----"+unekoa.getIz());
						System.out.println("---------------");
					}else if (x==2 ) {
						auk.sartuErreplika(unekoa);
						auk.sartuBiderkatzailea(0.2);
						System.out.println("---------------");
						System.out.println("%20"+"-----"+auk.getIz()+"-----"+unekoa.getIz());
						System.out.println("---------------");
					}
				}
				for(int j=0; j<auk.getErreplika().size();j++) {
					System.out.println("<><><><>");
					System.out.println(auk.getErreplika().get(j).getIz()+"<><>"+auk.getBiderkatzailea().get(j).toString());
					System.out.println("<><><><>");
				}
			}
		});
		
		
		
		/*
		
		for(int i=0; i<erab.size();i++) {
			err.add(i, (Erregistratua) erab.get(i));
		}
		lehen = err.get(0).getAkumulatuta();
		bigarren = err.get(0).getAkumulatuta();
		hiru = err.get(0).getAkumulatuta();
		
		for(int j =1; j<err.size();j++) {
			if(err.get(j).getAkumulatuta()>lehen) {
				hiru = bigarren;
				bigarren = lehen;
				lehen = err.get(j).getAkumulatuta();
			}else if(err.get(j).getAkumulatuta()>bigarren) {
				hiru = bigarren;
				bigarren = err.get(j).getAkumulatuta();
			}else if(err.get(j).getAkumulatuta()>hiru) {
				hiru = err.get(j).getAkumulatuta();
			}
		}
		
		lehena.setText(Double.toString(lehen));
		bigarrena.setText(Double.toString(bigarren));
		hirugarren.setText(Double.toString(hiru));
		
		}catch(Exception e) {
			lehena.setText("---------");
			bigarrena.setText("---------");
			hirugarren.setText("---------");
		}*/
	}
	
	
	public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}
	private void jButtonClose_actionPerformed(ActionEvent e) {
		this.setVisible(false);
	}
}
