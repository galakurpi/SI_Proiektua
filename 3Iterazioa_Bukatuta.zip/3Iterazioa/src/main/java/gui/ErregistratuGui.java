package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import businessLogic.BLFacade;
import domain.Apustua;
import domain.Erabiltzailea;
import domain.Erregistratua;

import javax.swing.JButton;
import javax.swing.JPanel;

public class ErregistratuGui {

	private JFrame frame;
	private JPasswordField pass;
	private JTextField erab;
	private JTextField NAN;
	private JTextField adina;
	// private JTextPane errorText;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ErregistratuGui window = new ErregistratuGui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ErregistratuGui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblErabiltzaileIzena = new JLabel("Erabiltzaile izena:");
		lblErabiltzaileIzena.setBounds(63, 45, 86, 14);
		frame.getContentPane().add(lblErabiltzaileIzena);

		JLabel lblNanZenbakia = new JLabel("NAN zenbakia:");
		lblNanZenbakia.setBounds(63, 88, 99, 14);
		frame.getContentPane().add(lblNanZenbakia);

		JLabel lblAdina = new JLabel("Adina:");
		lblAdina.setBounds(63, 135, 46, 14);
		frame.getContentPane().add(lblAdina);

		JLabel lblPasahitza = new JLabel("Pasahitza:");
		lblPasahitza.setBounds(63, 181, 86, 14);
		frame.getContentPane().add(lblPasahitza);

		pass = new JPasswordField();
		pass.setBounds(212, 178, 112, 20);
		frame.getContentPane().add(pass);

		erab = new JTextField();
		erab.setBounds(212, 42, 112, 20);
		frame.getContentPane().add(erab);
		erab.setColumns(10);

		NAN = new JTextField();
		NAN.setBounds(212, 85, 112, 20);
		frame.getContentPane().add(NAN);
		NAN.setColumns(10);

		adina = new JTextField();
		adina.setBounds(212, 132, 112, 20);
		frame.getContentPane().add(adina);
		adina.setColumns(10);

		JButton erreg = new JButton("Erregistratu");
		erreg.setBounds(160, 227, 89, 23);
		frame.getContentPane().add(erreg);

		final JTextPane errorText = new JTextPane();
		errorText.setBounds(63, 264, 324, 48);
		frame.getContentPane().add(errorText);

		erreg.addActionListener(new ActionListener() {

//			  public void actionPerformed(ActionEvent e) { 
//			    ;
//			  } 
//	} );

			public void actionPerformed(ActionEvent e) {

				BLFacade fac = MainGUI.getBusinessLogic();
				String izena = erab.getText();
				String pasahitza = pass.getText();
				String nan = NAN.getText();
				String adi = adina.getText();
				try {
					if (izena.isEmpty() || pasahitza.isEmpty() || nan.isEmpty() || adi.isEmpty()) {
						errorText.setText("Ezin da eremurik hutsik utzi.");
					} else if (Integer.parseInt(adi) < 18) {
						errorText.removeAll();
						errorText.setText("Gutxienez 18 urte eduki behar dira.");
					}

					else if (MainGUI.getBusinessLogic().erabiltzaileaBadago(izena, pasahitza) == null) {
						LoginGUI a = new LoginGUI();
						a.setVisible(true);
						frame.setVisible(false);
						Erregistratua er = new Erregistratua(izena, nan, adi, pasahitza);
						//er.addApustua(new Apustua(3, null, null, null, 4, "aitor"));
						fac.gordeErabiltzailea(er);
						MainGUI.getBusinessLogic().imprimatuErabiltzaileGuztiak();
						System.out.println("Ongi erregistratu zara.");
					} else {
						errorText.removeAll();
						errorText.setText("Erabiltzaile izena okupaturik dago.");
					}

				} catch (java.lang.NumberFormatException f) {
					errorText.removeAll();
					errorText.setText("Adina eremuan zenbakiak idatzi behar dituzu!");
				}
			}
		});

	}

	public void setVisible(boolean b) {
		frame.setVisible(b);

	}
}
