package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import domain.Event;
import domain.Question;
import exceptions.KuotaAlreadyExist;
import businessLogic.BLFacade;
import businessLogic.BLFacadeImplementation;
import configuration.UtilDate;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class GalderaEmaitzaGUI {

	BLFacade facade=MainGUI.getBusinessLogic();
	
	private JFrame frame;
	private JTextField galdera1x2;
	private JTextField info;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GalderaEmaitzaGUI window = new GalderaEmaitzaGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GalderaEmaitzaGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		final JComboBox<Event> Gertaerak = new JComboBox<Event>();
		Gertaerak.setBounds(32, 31, 369, 27);
		frame.getContentPane().add(Gertaerak);
		
		final JComboBox<Question> galderak = new JComboBox<Question>();
		galderak.setBounds(32, 86, 369, 27);
		frame.getContentPane().add(galderak);
		
		JLabel lblGertaerak = new JLabel("Gertaerak");
		lblGertaerak.setBounds(32, 6, 61, 16);
		frame.getContentPane().add(lblGertaerak);
		
		JLabel lblGalderak = new JLabel("Galderak");
		lblGalderak.setBounds(32, 70, 61, 16);
		frame.getContentPane().add(lblGalderak);
		
		galdera1x2 = new JTextField();
		galdera1x2.setBounds(132, 189, 130, 26);
		frame.getContentPane().add(galdera1x2);
		galdera1x2.setColumns(10);
	
		
		
		
		final JLabel labelgaldera1x2 = new JLabel("Emaitza:");
		labelgaldera1x2.setBounds(20, 194, 100, 16);
		frame.getContentPane().add(labelgaldera1x2);
		
		
		
		final JButton gorde = new JButton("GORDE");
		gorde.setBounds(313, 189, 117, 29);
		frame.getContentPane().add(gorde);
		//galderak.setVisible(false);
		
		
		Vector<Event> ev = facade.getAllEvents();
		
		for(int i =0; i < ev.size();i++) {
			Gertaerak.addItem(ev.get(i));	
		}
		
		Gertaerak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Event ev1 = (Event) Gertaerak.getSelectedItem();
				
				Vector<Question> q = ev1.getQuestions();
				
				galderak.removeAllItems();
				for(int j = 0; j<q.size();j++) {
				galderak.addItem(q.get(j));
				}
				
				
			}});
				//Question ga = (Question) galderak.getSelectedItem();
				galderak.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent o) {
						Question ga = (Question) galderak.getSelectedItem();
						
					}});
				Gertaerak.setSelectedIndex(0);
				Gertaerak.setSelectedIndex(0);
				
				JButton jButtonClose = new JButton("Close");
				jButtonClose.setBounds(313, 230, 117, 29);
				frame.getContentPane().add(jButtonClose);
				
				jButtonClose.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						jButtonClose_actionPerformed(e);
					}
				});
				
				gorde.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent v) {
						Question ga = (Question) galderak.getSelectedItem();
						BLFacade bl = MainGUI.getBusinessLogic();
						String emaitza1x2=galdera1x2.getText();
						bl.gordeEmaitza(ga,emaitza1x2);
						
						
						
						
			
						
						
					}});
							
						
						
				
		
	}
	
//	createKuota.addActionListener(new ActionListener() {
//		
//		public void actionPerformed(ActionEvent e) {
//		
//		CreateKuotaGUI a = new CreateKuotaGUI();
//		a.setVisible(true);
//		
//	}
//	
//	});
	
public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}

private void jButtonClose_actionPerformed(ActionEvent e) {
	this.setVisible(false);
}
}
