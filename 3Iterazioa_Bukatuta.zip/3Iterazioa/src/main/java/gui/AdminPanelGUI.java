package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;

import domain.Event;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;

public class AdminPanelGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPanelGUI window = new AdminPanelGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminPanelGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAukeratu = new JLabel("SELECT OPTION");
		lblAukeratu.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAukeratu.setForeground(Color.BLACK);
		lblAukeratu.setHorizontalAlignment(SwingConstants.CENTER);
		lblAukeratu.setBounds(0, 0, 434, 60);
		frame.getContentPane().add(lblAukeratu);
		
		JButton gertSort = new JButton("MANAGE EVENTS");
		gertSort.setFont(new Font("Tahoma", Font.PLAIN, 13));
		gertSort.setBounds(0, 49, 434, 60);
		frame.getContentPane().add(gertSort);
		
		JButton galdSort = new JButton("CREATE QUESTION");
		galdSort.setFont(new Font("Tahoma", Font.PLAIN, 13));
		galdSort.setBounds(0, 107, 434, 60);
		frame.getContentPane().add(galdSort);
		
		JButton galdKonts = new JButton("QUERY QUESTION");
		galdKonts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		galdKonts.setFont(new Font("Tahoma", Font.PLAIN, 13));
		galdKonts.setBounds(113, 231, 200, 41);
		frame.getContentPane().add(galdKonts);
		
		JButton createKuota = new JButton("CREATE SHARE");
		galdSort.setFont(new Font("Tahoma", Font.PLAIN, 13));
		createKuota.setBounds(0, 166, 434, 53);
		frame.getContentPane().add(createKuota);
		
		JButton galderaEmaitza = new JButton("CREATE EMAITZA");
		galdSort.setFont(new Font("Tahoma", Font.PLAIN, 13));
		galderaEmaitza.setBounds(0, 284, 434, 53);
		frame.getContentPane().add(galderaEmaitza);
		
		galderaEmaitza.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			
			GalderaEmaitzaGUI a = new GalderaEmaitzaGUI();
			a.setVisible(true);
			
		}
		
		});
		
		createKuota.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
			
			CreateKuotaGUI a = new CreateKuotaGUI();
			a.setVisible(true);
			
		}
		
		});
		
		gertSort.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				ManageEventsGUI a = new ManageEventsGUI();
				a.setVisible(true);
				//frame.setVisible(false);	
				System.out.println("Erabiltzaile zuzena. ADMIN zara.");
				
			}
		});
		
		galdSort.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				CreateQuestionGUI a = new CreateQuestionGUI(new Vector<Event>());
				a.setVisible(true);
			}
		});
		
		galdKonts.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				FindQuestionsGUI a = new FindQuestionsGUI();
				a.setVisible(true);
			}
		});
		
	}
public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}
}
