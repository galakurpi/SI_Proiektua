package gui;

import java.awt.EventQueue;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JComboBox;

import domain.Apustua;
import domain.Erregistratua;
import domain.Event;
import domain.Question;
import exceptions.KuotaAlreadyExist;
import businessLogic.BLFacade;
import businessLogic.BLFacadeImplementation;
import configuration.UtilDate;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;

public class ApustuaEzabatuGUI {

	BLFacade facade=MainGUI.getBusinessLogic();
	
	private JFrame frame;
	private JTextField galdera1x2;
	private JTextField info;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApustuaEzabatuGUI window = new ApustuaEzabatuGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ApustuaEzabatuGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Erregistratua unekoErreg =(Erregistratua) MainGUI.getBusinessLogic().erabiltzaileaBadago(MainGUI.izena, MainGUI.pasahitza);
		
		final JComboBox<Apustua> apustuak = new JComboBox<Apustua>();
		apustuak.setBounds(32, 31, 369, 27);
		for(Apustua a :unekoErreg.getApustua()) {
			apustuak.addItem(a);
			//System.out.println( a);
		}
			
		
			
			
			
		frame.getContentPane().add(apustuak);
		
		//=MainGUI.izena.
		
		
		
		
		JLabel lblGertaerak = new JLabel("Gertaerak");
		lblGertaerak.setBounds(32, 6, 61, 16);
		frame.getContentPane().add(lblGertaerak);
		
		
		galdera1x2 = new JTextField();
		galdera1x2.setBounds(132, 189, 130, 26);
		//frame.getContentPane().add(galdera1x2);
		galdera1x2.setColumns(10);
	
		
		
		
		
		
		
		final JButton ezabatu = new JButton("Ezabatu");
		ezabatu.setBounds(213, 100, 117, 29);
		frame.getContentPane().add(ezabatu);
		
		JButton jButtonClose = new JButton("Close");
		jButtonClose.setBounds(236, 230, 117, 29);
		frame.getContentPane().add(jButtonClose);
		
		jButtonClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jButtonClose_actionPerformed(e);
			}
		});
		
		
		//galderak.setVisible(false);
		
		
		
		
		ezabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Apustua a =(Apustua) apustuak.getSelectedItem();
				//System.out.println(a);
				MainGUI.getBusinessLogic().ezabatuApustua(a);		
			}});
		
		
		
		}
	

	
public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}

private void jButtonClose_actionPerformed(ActionEvent e) {
	this.setVisible(false);
}
}
