package gui;

/**
 * @author Software Engineering teachers
 */


import javax.swing.*;

import domain.Event;
import businessLogic.BLFacade;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MainGUI extends JFrame {
	
	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;
	private JButton jButtonCreateQuery = null;
	private JButton jButtonQueryQueries = null;
	private JButton jButtonDiruaSartu = null;
	private JButton jApustuaEzabatu = null;
	private JButton jMugimenduakIkusi = null;

	
    private static BLFacade appFacadeInterface;
	public static boolean adminDa= false;
	public static String izena= null;
	public static String pasahitza= null;
	
	
	public static BLFacade getBusinessLogic(){
		return appFacadeInterface;
	}
	
	public static void setBussinessLogic (BLFacade afi){
		appFacadeInterface=afi;
	}
	protected JLabel jLabelSelectOption;
	private JRadioButton rdbtnNewRadioButton;
	private JRadioButton rdbtnNewRadioButton_1;
	private JRadioButton rdbtnNewRadioButton_2;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JButton Rankin;
	
	/**
	 * This is the default constructor
	 */
	public MainGUI() {
		super();
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				try {
					//if (ConfigXML.getInstance().isBusinessLogicLocal()) facade.close();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					System.out.println("Error: "+e1.toString()+" , probably problems with Business Logic or Database");
				}
				System.exit(1);
			}
		});

		initialize();
		//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		// this.setSize(271, 295);
		this.setSize(495, 290);
		this.setContentPane(getJContentPane());
		this.setTitle(ResourceBundle.getBundle("Etiquetas").getString("MainTitle"));
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getLblNewLabel());
			jContentPane.add(getBoton3());
			//jContentPane.add(getBoton2());
			jContentPane.add(getBoton4());
			jContentPane.add(getBoton5());
			jContentPane.add(getRdbtnNewRadioButton_1());
			jContentPane.add(getBoton6());
			jContentPane.add(getRdbtnNewRadioButton_2());
			jContentPane.add(getRdbtnNewRadioButton());
			jContentPane.add(getRankin());
			
			
		}
		return jContentPane;
	}


	/**
	 * This method initializes boton1
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBoton2() {
		if (jButtonCreateQuery == null) {
			jButtonCreateQuery = new JButton();
			jButtonCreateQuery.setText(ResourceBundle.getBundle("Etiquetas").getString("CreateQuery"));
			if (adminDa) {
				jButtonCreateQuery.setEnabled(true);	
			}else {
			jButtonCreateQuery.setEnabled(false);
			}
			jButtonCreateQuery.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JFrame a = new CreateQuestionGUI(new Vector<Event>());
					a.setVisible(true);
				}
			});
		}
		return jButtonCreateQuery;
	}
	private JButton getBoton4() {
		if (jButtonDiruaSartu == null) {
			jButtonDiruaSartu = new JButton();
			jButtonDiruaSartu.setBounds(0, 50, 239, 50);
			jButtonDiruaSartu.setText(ResourceBundle.getBundle("Etiquetas").getString("DiruaManeiatu"));
			
				jButtonDiruaSartu.setEnabled(true);	
		
			jButtonDiruaSartu.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					DiruaGUI a = new DiruaGUI();
					a.setVisible(true);
				}
			});
		}
		return jButtonDiruaSartu;
	}
	private JButton getBoton5() {
		if (jApustuaEzabatu == null) {
			jApustuaEzabatu = new JButton();
			jApustuaEzabatu.setBounds(239, 50, 239, 50);
			jApustuaEzabatu.setText(ResourceBundle.getBundle("Etiquetas").getString("ApustuaEzabatu"));
			
			jApustuaEzabatu.setEnabled(true);	
		
			jApustuaEzabatu.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					ApustuaEzabatuGUI a = new ApustuaEzabatuGUI();
					a.setVisible(true);
				}
			});
		}
		return jApustuaEzabatu;
	}
	
	private JButton getBoton6() {
		if (jMugimenduakIkusi == null) {
			jMugimenduakIkusi = new JButton();
			jMugimenduakIkusi.setBounds(239, 111, 239, 50);
			jMugimenduakIkusi.setText(ResourceBundle.getBundle("Etiquetas").getString("Mugimenduakikusi"));
			
			jMugimenduakIkusi.setEnabled(true);	
		
			jMugimenduakIkusi.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					MugimenduakGUI a = new MugimenduakGUI();
					a.setVisible(true);
				}
			});
		}
		return jMugimenduakIkusi;
	}
	
	
	
	/**
	 * This method initializes boton2
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBoton3() {
		if (jButtonQueryQueries == null) {
			jButtonQueryQueries = new JButton();
			jButtonQueryQueries.setBounds(0, 111, 239, 50);
			jButtonQueryQueries.setText(ResourceBundle.getBundle("Etiquetas").getString("QueryQueries"));
			jButtonQueryQueries.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JFrame a = new FindQuestionsGUI();

					a.setVisible(true);
				}
			});
		}
		return jButtonQueryQueries;
	}
	

	private JLabel getLblNewLabel() {
		if (jLabelSelectOption == null) {
			jLabelSelectOption = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("SelectOption"));
			jLabelSelectOption.setBounds(118, 0, 239, 50);
			jLabelSelectOption.setFont(new Font("Tahoma", Font.BOLD, 13));
			jLabelSelectOption.setForeground(Color.BLACK);
			jLabelSelectOption.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return jLabelSelectOption;
	}
	
	private JRadioButton getRdbtnNewRadioButton() {
		if (rdbtnNewRadioButton == null) {
			rdbtnNewRadioButton = new JRadioButton("English");
			rdbtnNewRadioButton.setBounds(351, 225, 59, 23);
			rdbtnNewRadioButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Locale.setDefault(new Locale("en"));
					System.out.println("Locale: "+Locale.getDefault());
					redibujar();				}
			});
			buttonGroup.add(rdbtnNewRadioButton);
		}
		return rdbtnNewRadioButton;
	}
	private JRadioButton getRdbtnNewRadioButton_1() {
		if (rdbtnNewRadioButton_1 == null) {
			rdbtnNewRadioButton_1 = new JRadioButton("Euskara");
			rdbtnNewRadioButton_1.setBounds(53, 221, 84, 31);
			rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Locale.setDefault(new Locale("eus"));
					System.out.println("Locale: "+Locale.getDefault());
					redibujar();				}
			});
			buttonGroup.add(rdbtnNewRadioButton_1);
		}
		return rdbtnNewRadioButton_1;
	}
	private JRadioButton getRdbtnNewRadioButton_2() {
		if (rdbtnNewRadioButton_2 == null) {
			rdbtnNewRadioButton_2 = new JRadioButton("Castellano");
			rdbtnNewRadioButton_2.setBounds(199, 225, 75, 23);
			rdbtnNewRadioButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Locale.setDefault(new Locale("es"));
					System.out.println("Locale: "+Locale.getDefault());
					redibujar();
				}
			});
			buttonGroup.add(rdbtnNewRadioButton_2);
		}
		return rdbtnNewRadioButton_2;
	}
	
	private void redibujar() {
		jLabelSelectOption.setText(ResourceBundle.getBundle("Etiquetas").getString("SelectOption"));
		jButtonQueryQueries.setText(ResourceBundle.getBundle("Etiquetas").getString("QueryQueries"));
		//jButtonCreateQuery.setText(ResourceBundle.getBundle("Etiquetas").getString("CreateQuery"));
		jButtonDiruaSartu.setText(ResourceBundle.getBundle("Etiquetas").getString("DiruaManeiatu"));
		jApustuaEzabatu.setText(ResourceBundle.getBundle("Etiquetas").getString("ApustuaEzabatu"));
		jMugimenduakIkusi.setText(ResourceBundle.getBundle("Etiquetas").getString("Mugimenduakikusi"));
		this.setTitle(ResourceBundle.getBundle("Etiquetas").getString("MainTitle"));
	}
	
	
	private JButton getRankin() {
		if (Rankin == null) {
			Rankin = new JButton(ResourceBundle.getBundle("Etiquetas").getString("MainGUI.btnNewButton.text")); //$NON-NLS-1$ //$NON-NLS-2$
			Rankin.setBounds(118, 173, 239, 50);
			Rankin.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					RankinGUI a = new RankinGUI();

					a.setVisible(true);
				}
			});
		}
		return Rankin;
	}
	
} // @jve:decl-index=0:visual-constraint="0,0"

