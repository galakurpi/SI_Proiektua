package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import domain.Event;
import domain.Question;
import exceptions.KuotaAlreadyExist;
import businessLogic.BLFacade;
import businessLogic.BLFacadeImplementation;
import configuration.UtilDate;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class CreateKuotaGUI {

	BLFacade facade=MainGUI.getBusinessLogic();
	
	private JFrame frame;
	private JTextField bider;
	private JTextField info;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateKuotaGUI window = new CreateKuotaGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CreateKuotaGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		final JComboBox<Event> Gertaerak = new JComboBox<Event>();
		Gertaerak.setBounds(32, 31, 369, 27);
		frame.getContentPane().add(Gertaerak);
		
		final JComboBox<Question> galderak = new JComboBox<Question>();
		galderak.setBounds(32, 86, 369, 27);
		frame.getContentPane().add(galderak);
		
		JLabel lblGertaerak = new JLabel("Gertaerak");
		lblGertaerak.setBounds(32, 6, 61, 16);
		frame.getContentPane().add(lblGertaerak);
		
		JLabel lblGalderak = new JLabel("Galderak");
		lblGalderak.setBounds(32, 70, 61, 16);
		frame.getContentPane().add(lblGalderak);
		
		bider = new JTextField();
		bider.setBounds(132, 189, 130, 26);
		frame.getContentPane().add(bider);
		bider.setColumns(10);
		
		info = new JTextField();
		info.setColumns(10);
		info.setBounds(132, 227, 130, 26);
		frame.getContentPane().add(info);
		
		JLabel lblKuota = new JLabel("Kuota");
		lblKuota.setBounds(32, 161, 61, 16);
		frame.getContentPane().add(lblKuota);
		
		JLabel lblBiderkatzailea = new JLabel("Biderkatzailea:");
		lblBiderkatzailea.setBounds(20, 194, 100, 16);
		frame.getContentPane().add(lblBiderkatzailea);
		
		JLabel lblInformazioa = new JLabel("Informazioa:");
		lblInformazioa.setBounds(20, 232, 113, 16);
		frame.getContentPane().add(lblInformazioa);
		
		final JButton gorde = new JButton("GORDE");
		gorde.setBounds(314, 189, 117, 29);
		frame.getContentPane().add(gorde);
		//galderak.setVisible(false);
		
		
		Vector<Event> ev = facade.getAllEvents();
		
		for(int i =0; i < ev.size();i++) {
			Gertaerak.addItem(ev.get(i));	
		}
		
		Gertaerak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Event ev1 = (Event) Gertaerak.getSelectedItem();
				
				Vector<Question> q = ev1.getQuestions();
				
				galderak.removeAllItems();
				for(int j = 0; j<q.size();j++) {
				galderak.addItem(q.get(j));
				}
				
				
			}});
				//Question ga = (Question) galderak.getSelectedItem();
				galderak.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent o) {
						Question ga = (Question) galderak.getSelectedItem();
						
					}});
				Gertaerak.setSelectedIndex(0);
				Gertaerak.setSelectedIndex(0);
				
				JButton jButtonClose = new JButton("Close");
				jButtonClose.setBounds(314, 232, 117, 29);
				frame.getContentPane().add(jButtonClose);
				jButtonClose.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						jButtonClose_actionPerformed(e);
					}
				});
				
				
				gorde.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent v) {
						Question ga = (Question) galderak.getSelectedItem();
						BLFacade bl = MainGUI.getBusinessLogic();
						final float bi = Float.parseFloat(bider.getText());
						final String in = info.getText();
						
						if(bi<=1.0 || in == ""){
							System.out.println("Eremuak gaizki daude");
						}else {
						try {
							
							bl.createKuota(ga, bi, in);
						} catch (KuotaAlreadyExist e) {
							System.out.println("Kuota existitzen da");
							e.printStackTrace();
						}
						}
						
					}});
							
						
						
				
		
	}
	
//	createKuota.addActionListener(new ActionListener() {
//		
//		public void actionPerformed(ActionEvent e) {
//		
//		CreateKuotaGUI a = new CreateKuotaGUI();
//		a.setVisible(true);
//		
//	}
//	
//	});
	
public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}
private void jButtonClose_actionPerformed(ActionEvent e) {
	this.setVisible(false);
}
}
