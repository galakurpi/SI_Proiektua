package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class LoginGUI  {

	private JFrame frame;
	private JTextField erab;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI window = new LoginGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginGUI(){
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblErabiltzaileIzena = new JLabel("Erabiltzaile izena:");
		lblErabiltzaileIzena.setBounds(37, 54, 93, 14);
		frame.getContentPane().add(lblErabiltzaileIzena);
		
		JLabel lblPasahitza = new JLabel("Pasahitza: ");
		lblPasahitza.setBounds(37, 97, 66, 14);
		frame.getContentPane().add(lblPasahitza);
		
		erab = new JTextField();
		erab.setBounds(170, 51, 128, 20);
		frame.getContentPane().add(erab);
		erab.setColumns(10);
		
		pass = new JPasswordField();
		pass.setBounds(170, 94, 128, 20);
		frame.getContentPane().add(pass);
		
		JButton log = new JButton("Login");
		log.setBounds(121, 164, 89, 23);
		frame.getContentPane().add(log);
		
		JButton erreg = new JButton("Erregistratu");
		erreg.setBounds(241, 164, 150, 23);
		frame.getContentPane().add(erreg);
		
		
		log.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				String izena=erab.getText();
				String pasahitza=pass.getText();
				if(izena.equals("admin") && pasahitza.equals("admin")) {
					MainGUI.adminDa=true;
					AdminPanelGUI a = new AdminPanelGUI();
					a.setVisible(true);
					frame.setVisible(false);	
					System.out.println("Erabiltzaile zuzena. ADMIN zara.");
				}else if(MainGUI.getBusinessLogic().erabiltzaileaZuzenaDa(izena,pasahitza)) {
					MainGUI.adminDa=false;
					MainGUI.izena=izena;
					MainGUI.pasahitza=pasahitza;
					MainGUI a = new MainGUI();
					a.setVisible(true);
					frame.setVisible(false);	
					System.out.println("Erabiltzaile zuzena.");
				}else {
					System.out.println("Erabiltzailea edo pasahitza okerrak.");
				}
			
				
			}
		});
		
		
		erreg.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				ErregistratuGui a = new ErregistratuGui(); 
				
				a.setVisible(true);
				
				frame.setVisible(false);

				
			}
		});
		
	}

	public void setVisible(boolean b) {
		
		frame.setVisible(b);
	}
}
