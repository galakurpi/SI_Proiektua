package service;

import javax.jws.WebService;

@WebService
public interface WebServiceLogicInterface {

}
