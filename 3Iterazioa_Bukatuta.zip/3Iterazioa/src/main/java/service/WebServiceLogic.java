package service;

public class WebServiceLogic {

}
