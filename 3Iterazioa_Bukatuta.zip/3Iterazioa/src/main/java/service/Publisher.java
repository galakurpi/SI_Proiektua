package service;

public class Publisher {

}
