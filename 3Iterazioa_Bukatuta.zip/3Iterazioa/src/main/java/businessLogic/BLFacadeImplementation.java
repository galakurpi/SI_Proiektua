package businessLogic;

import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.jws.WebMethod;
import javax.jws.WebService;

import configuration.ConfigXML;
import dataAccess.DataAccess;
import domain.Question;
import domain.Apustua;
import domain.Erabiltzailea;
import domain.Erregistratua;
import domain.Event;
import domain.Kuota;
import domain.Mugimendua;
import exceptions.EventFinished;
import exceptions.KuotaAlreadyExist;
import exceptions.QuestionAlreadyExist;
import gui.GalderaEmaitzaGUI;
import gui.MainGUI;

/**
 * It implements the business logic as a web service.
 */
@WebService(endpointInterface = "businessLogic.BLFacade")
public class BLFacadeImplementation  implements BLFacade {

	public BLFacadeImplementation()  {		
		System.out.println("Creating BLFacadeImplementation instance");
		ConfigXML c=ConfigXML.getInstance();
		boolean hasieratu=false;
		
		DataAccess dbManager;
		if(hasieratu) {
			dbManager=new DataAccess(true);
			dbManager.initializeDB();
		}else
		{
			dbManager=new DataAccess(false);
		}
		
		
		
//		if (c.getDataBaseOpenMode().equals("initialize")) {
//			//Datu basea reseteatzeko
//			DataAccess dbManager=new DataAccess(c.getDataBaseOpenMode().equals("initialize"));
//			
//			
//			
//			dbManager.close();
//			}
		
	}
	

	/**
	 * This method creates a question for an event, with a question text and the minimum bet
	 * 
	 * @param event to which question is added
	 * @param question text of the question
	 * @param betMinimum minimum quantity of the bet
	 * @return the created question, or null, or an exception
	 * @throws EventFinished if current data is after data of the event
 	 * @throws QuestionAlreadyExist if the same question already exists for the event
	 */
   @WebMethod
   public Question createQuestion(Event event, String question, float betMinimum) throws EventFinished, QuestionAlreadyExist{
	   
	    //The minimum bed must be greater than 0
	    DataAccess dBManager=new DataAccess();
		Question qry=null;
		
	    
		if(new Date().compareTo(event.getEventDate())>0)
			throw new EventFinished(ResourceBundle.getBundle("Etiquetas").getString("ErrorEventHasFinished"));
				
		
		 qry=dBManager.createQuestion(event,question,betMinimum);		

		dBManager.close();
		
		return qry;
   };
   
   @WebMethod
   public Kuota createKuota(Question galdera, float bider, String inf) throws KuotaAlreadyExist{
	   
	   DataAccess dBManager=new DataAccess();
		Kuota kuo=null;
		
		
		kuo=dBManager.createKuota(galdera,bider, inf);		

		dBManager.close();
		
		return kuo;
   }
	
	/**
	 * This method invokes the data access to retrieve the events of a given date 
	 * 
	 * @param date in which events are retrieved
	 * @return collection of events
	 */
    @WebMethod	
	public Vector<Event> getEvents(Date date)  {
		DataAccess dbManager=new DataAccess();
		Vector<Event>  events=dbManager.getEvents(date);
		dbManager.close();
		return events;
	}

    @WebMethod
    public Vector<Event> getAllEvents()  {
		DataAccess dbManager=new DataAccess();
		Vector<Event>  events=dbManager.getAllEvents();
		dbManager.close();
		return events;
	}
    
    @WebMethod
    public Vector<Mugimendua> getAllMugs(){
    	DataAccess dbManager=new DataAccess();
		Vector<Mugimendua> mugs=dbManager.getAllMugs();
		dbManager.close();
		return mugs;
    }
    
    @WebMethod
    public List<Erabiltzailea> lortuErabiltzaileGuztiak(){
    	DataAccess dbManager=new DataAccess();
    	List<Erabiltzailea> erab=dbManager.lortuErabiltzaileGuztiak();
		dbManager.close();
		return erab;
    }
    
	/**
	 * This method invokes the data access to retrieve the dates a month for which there are events
	 * 
	 * @param date of the month for which days with events want to be retrieved 
	 * @return collection of dates
	 */
	@WebMethod public Vector<Date> getEventsMonth(Date date) {
		DataAccess dbManager=new DataAccess();
		Vector<Date>  dates=dbManager.getEventsMonth(date);
		dbManager.close();
		return dates;
	}
	
	
	@WebMethod public boolean erabiltzaileaZuzenaDa(String izena,String pasahitza) {
		DataAccess dbManager=new DataAccess();
	
		for(Erabiltzailea e : dbManager.lortuErabiltzaileGuztiak()) {
			if(izena.equals(e.getIz()) && pasahitza.equals(e.getPasahitza())) {
				return true;
			}
		}
		dbManager.close();
		return false;
		
	}
	@WebMethod public double erabiltzaileSaldoa(String izena,String pasahitza) {
		DataAccess dbManager=new DataAccess();
		double ema=dbManager.erabiltzaileSaldoa(izena, pasahitza);
		
		dbManager.close();
		return ema;
		
	}
	@WebMethod public void saldoaGehitu(String izena,double saldoa) {
		DataAccess dbManager=new DataAccess();
	    dbManager.saldoaGehitu(izena, saldoa);
		
		dbManager.close();	
	}
	
	@WebMethod public void akumulatu(String izena,double dirua) {
		DataAccess dbManager=new DataAccess();
	    dbManager.akumulatu(izena, dirua);
		
		dbManager.close();	
	}
	
	@WebMethod public void ezabatuApustua(Apustua a) {
		DataAccess dbManager=new DataAccess();
	    dbManager.ezabatuApustua(a);
		
		dbManager.close();
	
		
	}
	
	@WebMethod public void ezabatuGertaera(Event a) {
		DataAccess dbManager=new DataAccess();
	    dbManager.ezabatuGertaera(a);
		
		dbManager.close();
	
		
	}
	
	
	
	@WebMethod public Erabiltzailea erabiltzaileaBadago(String izena,String pasahitza) {
		DataAccess dbManager=new DataAccess();
		Erabiltzailea isLog = dbManager.erabiltzaileaBadago(izena, pasahitza);
		dbManager.close();
		return isLog;
	
//		for(Erabiltzailea e : dbManager.lortuErabiltzaileGuztiak()) {
//			if(izena.equals(e.getIz()) && pasahitza.equals(e.getPasahitza())) {
//				
//				return false;
//			}else {
//				return true;
//				
//			}
//		}
//		dbManager.close();
//		return true;
		
	}
	
	@WebMethod public void gordeErabiltzailea(Erabiltzailea o) {
		DataAccess userM = new DataAccess();
		userM.gordeErabiltzailea(o);
		userM.close();
	}
	@WebMethod public void gordeEmaitza(Question g,String o) {
		DataAccess db = new DataAccess();
		db.gordeEmaitza(g,o);
		
		for(Erabiltzailea erab :db.lortuErabiltzaileGuztiak()){
			Erregistratua erreg =(Erregistratua) erab;
			for(Apustua a :erreg.getApustua()) {
				if(a.getGaldera().getQuestionNumber()==g.getQuestionNumber() && a.getAukeratutakoa().equals(o)) {
					
					saldoaGehitu(erreg.getIz(),a.getEtekina());
					akumulatu(erreg.getIz(), a.getEtekina());
			
					Mugimendua m = new Mugimendua(a.getEtekina(), "irabazi", new Date(),erreg);
					gordeMugimendua(m);
				}
			}
		}
		
		try {
		db.close();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

	@WebMethod public void imprimatuErabiltzaileGuztiak() {
		DataAccess dbManager = new DataAccess();
		System.out.println("Erabiltzaileak: ");
		for(Erabiltzailea e : dbManager.lortuErabiltzaileGuztiak()) {
			System.out.println(e.getNan()+"\t"+e.getIz()+"\t"+e.getPasahitza());
		}
		dbManager.close();
	}
	@WebMethod public void imprimatuGertaeraGuztiak() {
		DataAccess dbManager = new DataAccess();
		System.out.println("Gertaerak: ");
		for(Event e : dbManager.lortuGertaeraGuztiak()) {
			System.out.println(e.getDescription()+"\t"+e.getEventDate());
		}
		dbManager.close();
	}
	
	@WebMethod public boolean eventBadago(Event e) {
		DataAccess dbManager = new DataAccess();
		boolean bai = dbManager.eventBadago(e);
		dbManager.close();
		if(!bai) {
			return false;
		}
		return true;
	}
	
	@WebMethod public void gordeEvent(Event e) {
		DataAccess event = new DataAccess();
		event.gordeEvent(e);
		event.close();
	}
	
	@WebMethod public void gordeApustua(Apustua e) {
		DataAccess db = new DataAccess();
		db.gordeApustua(e);
		db.close();
	}
	
	@WebMethod public void gordeMugimendua(Mugimendua m) {
		DataAccess db = new DataAccess();
		db.gordeMugimendua(m);
		db.close();
	}
	
	/**
	 * This method invokes the data access to initialize the database with some events and questions.
	 * It is invoked only when the option "initialize" is declared in the tag dataBaseOpenMode of resources/config.xml file
	 */	
    @WebMethod	
	 public void initializeBD(){
		DataAccess dBManager=new DataAccess();
		dBManager.initializeDB();
		dBManager.close();
	}

}

