package domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Vector;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Apustua implements Serializable {
	@Id  @GeneratedValue
	@XmlID
	@XmlJavaTypeAdapter(IntegerAdapter.class)
	private Integer Id;
	private double dirua;
	private double etekina;
	private Question galdera;
	private Event gertaera;
	@XmlIDREF
	private Erregistratua erregistratua;
	private String aukeratutakoa;
	
	
	public Apustua() {
		
	}
	
	
	public Apustua(double dirua,Question galdera,Event gertaera,Erregistratua erregistratua,double etekina,String aukeratutakoa) {
		
		this.dirua=dirua;
		this.galdera=galdera;
		this.gertaera=gertaera;
		this.erregistratua=erregistratua;
		this.etekina=etekina;
		this.aukeratutakoa=aukeratutakoa;
		
		//this.Id="APUSTUA-"+erregistratua.getNan()+"-"+ gertaera.getEventNumber()+"-"+ galdera.getQuestionNumber();
	}



	public Integer getId() {
		return Id;
	}



	public double getDirua() {
		return dirua;
	}



	public Question getGaldera() {
		return galdera;
	}



	public Event getGertaera() {
		return gertaera;
	}




	public Erregistratua getErregistratua() {
		return erregistratua;
	}



	
	public double getEtekina() {
		return etekina;
	}

	
	
	public String getAukeratutakoa() {
		return aukeratutakoa;
	}
	
	
	
	public String toString() {
		return "Apustua: " + this.gertaera.getDescription() + "-" +  this.galdera.getQuestion() + "-" +this.getAukeratutakoa() + "-" + this.dirua;
	}
}
