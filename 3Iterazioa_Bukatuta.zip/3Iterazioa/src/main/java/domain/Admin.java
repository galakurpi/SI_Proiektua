package domain;
import java.io.Serializable;
import java.util.Vector;
import java.util.Date;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import domain.Erabiltzailea;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Admin extends Erabiltzailea {
	@Id
	@XmlID
	@XmlJavaTypeAdapter(IntegerAdapter.class)
	private Integer adminZb;

	

	public Admin(String iz, String nan, String adina, String pasahitza, Integer adminZb) {
		super(iz, nan,adina,pasahitza);
		this.adminZb=adminZb;
	}

	public Integer getAdminZb() {
		return adminZb;
	}

	public void setAdminZb(Integer adminZb) {
		this.adminZb = adminZb;
	}
	
	
	
}
