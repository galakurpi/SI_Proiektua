package domain;

import java.io.Serializable;
import java.util.Vector;
import java.util.Date;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import domain.Erabiltzailea;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Erregistratua extends Erabiltzailea {

	private double saldoa;
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.PERSIST)
	@XmlIDREF
	private Vector<Mugimendua> mugimendua=new Vector<Mugimendua>();
	
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@XmlIDREF
	private Vector<Apustua> apustuList=new Vector<Apustua>();
	
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.PERSIST)
	private Vector<Erregistratua> erreplika = new Vector<Erregistratua>();
	
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.PERSIST)
	private Vector<Double> biderkatzailea = new Vector<Double>();
	
	private double akumulatuta;
	
	public Erregistratua() {
		super();
	}
	
	public Vector<Erregistratua> getErreplika() {
		return erreplika;
	}

	public void setErreplika(Vector<Erregistratua> erreplika) {
		this.erreplika = erreplika;
	}

	public void sartuErreplika(Erregistratua berria) {
		erreplika.add(berria);
	}
	
	public Vector<Double> getBiderkatzailea() {
		return biderkatzailea;
	}

	public void setBiderkatzailea(Vector<Double> biderkatzailea) {
		this.biderkatzailea = biderkatzailea;
	}
	public void sartuBiderkatzailea(Double bi) {
		biderkatzailea.add(bi);
	}
	
	public Erregistratua(String iz, String nan, String adina, String pasahitza) {
		super(iz, nan, adina, pasahitza);
		this.saldoa=0;
	}
	
	public void addApustua(Apustua apustua) {
		this.apustuList.add(apustua);
	}
	public Vector<Apustua> getApustua() {
		return apustuList;
	}
	public double getSaldoa() {
		return saldoa;
	}
	public void setSaldoa(double saldoa) {
		this.saldoa = saldoa;
	}
	
	public void addSaldoa(double saldoa) {
		this.saldoa=this.saldoa+saldoa;
	}
	
	public void kenduSaldoa(double saldoa) {
		this.saldoa = this.saldoa-saldoa;
	}
	
		
	public Vector<Mugimendua> getMugimendua() {
		return mugimendua;
	}
	public void setMugimendua(Vector<Mugimendua> mugimendua) {
		this.mugimendua = mugimendua;
	}
	public void addMugimendua(Mugimendua m)  {
        //Mugimendua k=new Mugimendua(dirua, mota,data);
        mugimendua.add(m);
     
	}
	
	public double kalkulatuIrabazia() {
		double emaitza=0;
		for(Mugimendua m:this.mugimendua) {
			if(m.getMota().equals("irabazi")) {
				emaitza=emaitza+m.getDirua();
			}
		}		
		return emaitza;
		
	}
	
	public void removeApustua(Apustua a) {
		int ind=-1;
		for(int i =0;i<this.apustuList.size();i++) {
			if(this.apustuList.get(i).getId()==a.getId()) {
				ind=i;
			}
		}
		
		this.apustuList.remove(ind);
		
	}

	public double getAkumulatuta() {
		return akumulatuta;
	}

	public void setAkumulatuta(double akumulatuta) {
		this.akumulatuta = akumulatuta;
	}
	
	public void addAkumulatua(double akumulatua) {
		this.akumulatuta=this.akumulatuta + akumulatua;
	}
	
	
}

