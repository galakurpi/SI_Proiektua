package domain;


import java.text.SimpleDateFormat;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Mugimendua {

	private double dirua;
	private String mota;
	// sartu =dirua sartu; 
	// apostatu =apostua egi;
	// irabazi =apostua irabazi;
	private Date data;
	@XmlIDREF
	private Erregistratua erreg;
	@XmlID
	@XmlJavaTypeAdapter(IntegerAdapter.class)
	@Id @GeneratedValue
	private Integer mugId;
	
	public Mugimendua() {
	
	}
	
	public Mugimendua(double di, String mo, Date data, Erregistratua erreg) {
		this.dirua = di;
		this.mota = mo;
		this.data = data;
		this.setErreg(erreg);
	}
	

	public double getDirua() {
		return dirua;
	}

	public void setDirua(float dirua) {
		this.dirua = dirua;
	}
	
	public Integer getMugId() {
		return mugId;
	}

	public void setMugId(Integer mugId) {
		this.mugId = mugId;
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String toString() {
		String pattern = "HH:mm:ss MM-dd-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String d = simpleDateFormat.format(data);
		if( this.mota.equals("irabazi")) {
			return this.dirua +"� irabazi dituzu. (" + d+")";
		}else if(this.mota.equals("apostatu")) {
			return this.dirua +"� apostatu dituzu. (" + d+")";
		}else {
			return this.dirua +"� sartu dituzu. ("+ d +")";
			
		}
	}


	public Erregistratua getErreg() {
		return erreg;
	}


	public void setErreg(Erregistratua erreg) {
		this.erreg = erreg;
	}
	
}
