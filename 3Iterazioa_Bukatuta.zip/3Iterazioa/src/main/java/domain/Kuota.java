package domain;

import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Kuota {

	private float biderkatzailea;
	@Id @GeneratedValue
	@XmlJavaTypeAdapter(IntegerAdapter.class)
	@XmlID
	private Integer kuotaZb;
	private String info;
	private Question galdera;

	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@XmlIDREF
	private Vector<Apustua> apustuak = new Vector<Apustua>();
	public Kuota () {
		super();
	}
	
	public Kuota (float bider, int zb, String inf, Question galdera) {
		super();
		this.biderkatzailea = bider;
		this.kuotaZb = zb;
		this.info = inf;
	}

	public Kuota (float bider, String inf) {
		super();
		this.biderkatzailea = bider;
		this.info = inf;
	}
	
	public float getBiderkatzailea() {
		return biderkatzailea;
	}

	public void setBiderkatzailea(float biderkatzailea) {
		this.biderkatzailea = biderkatzailea;
	}

	public Integer getKuotaZb() {
		return kuotaZb;
	}

	public void setKuotaZb(Integer kuotaZb) {
		this.kuotaZb = kuotaZb;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Question getGaldera() {
		return galdera;
	}

	public void setGaldera(Question galdera) {
		this.galdera = galdera;
	}
	
	public Vector<Apustua> getApustuak() {
		return apustuak;
	}

	public void setApustuak(Vector<Apustua> apustuak) {
		this.apustuak = apustuak;
	}
	
	public void addApustuak(Apustua a) {
		apustuak.add(a);
	}

	public String toString(){
		return kuotaZb+";"+info+";"+Float.toString(biderkatzailea);
	}
	
	
}
