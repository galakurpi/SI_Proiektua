package domain;

import java.io.Serializable;
import java.util.Vector;
import java.util.Date;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity
@XmlSeeAlso ({Erregistratua.class, Admin.class})
@XmlAccessorType(XmlAccessType.FIELD)
public abstract class Erabiltzailea {
	
	
	//private int nanZb;
	//private char nanL;
	@Id
	@XmlID
	private String nan;
	private String iz;
	private String adina;
	private String pasahitza;
	
	public Erabiltzailea(String iz, String nan, String adina, String pasahitza) {
		this.iz=iz;
		this.nan=nan;
		this.adina=adina;
		this.pasahitza=pasahitza;
	}

	public Erabiltzailea() {
		// TODO Auto-generated constructor stub
	}

	public String getIz() {
		return iz;
	}

	public void setIz(String iz) {
		this.iz = iz;
	}

	public String getNan() {
		return nan;
	}

	public void setNan(String nan) {
		this.nan = nan;
	}

	public String getAdina() {
		return adina;
	}

	public void setAdina(String adina) {
		this.adina = adina;
	}

	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}
	
}